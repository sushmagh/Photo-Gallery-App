export const getErrors = (errors) => ({
  type: 'GET_ERRORS',
  errors
});
