import React from 'react';
import UploadForm from './UploadForm';

const HomePage = () => (
  <div className="home-page">
    <UploadForm />
  </div>
);

export default HomePage;
